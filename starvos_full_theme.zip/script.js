
function showAlert() {
  alert("Evil panel launched successfully!");
}
