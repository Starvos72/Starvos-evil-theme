
@extends('layouts.auth')

@section('content')
<div class="login-container">
  <h1>🩸 Welcome to Starvos</h1>
  <form method="POST" action="{{ route('auth.login') }}">
    @csrf
    <input name="email" type="email" placeholder="Email" required autofocus>
    <input name="password" type="password" placeholder="Password" required>
    <button type="submit">Login as Vampire</button>
  </form>
</div>
@endsection
