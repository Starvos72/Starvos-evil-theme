
const drop = document.createElement('div');
drop.className = 'blood-drip';
document.body.appendChild(drop);
