
function createBloodDrop() {
  const drop = document.createElement('div');
  drop.className = 'drop';
  drop.style.left = Math.random() * window.innerWidth + 'px';
  document.body.appendChild(drop);
  setTimeout(() => drop.remove(), 3000);
}

setInterval(createBloodDrop, 300);
